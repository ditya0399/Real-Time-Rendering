
#include <stdio.h> // for FILE I/O
#include<stdlib.h>
#include<math.h>
#include<GL/glew.h>
#include<GL/gl.h>
#include<GL/glx.h>
extern int Sphere(GLfloat, int, GLfloat **, GLfloat **, GLfloat **);
extern void make_cylinder(double , double , int , int );
extern void draw_cylinder();


